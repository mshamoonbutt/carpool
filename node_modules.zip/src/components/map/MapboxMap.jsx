// src/components/map/MapboxMap.jsx
import React, { useState, useRef, useEffect } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import './MapboxMap.css';

// Initialize Mapbox
mapboxgl.accessToken = 'pk.eyJ1Ijoic2hvY2tlZHJ1bWJsZSIsImEiOiJjbHlycDVwZjEwNnViMmxyMDJ2NXlpeWRiIn0.q8928pDyTpw51xqJouSQrQ';

const MapboxMap = ({ initialView = { lng: 74.3587, lat: 31.5204, zoom: 12 } }) => {
  const mapContainer = useRef(null);
  const [map, setMap] = useState(null);
  const [markers, setMarkers] = useState([]);

  // Initialize map
  useEffect(() => {
    const newMap = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [initialView.lng, initialView.lat],
      zoom: initialView.zoom
    });

    // Add navigation controls
    newMap.addControl(new mapboxgl.NavigationControl());

    setMap(newMap);

    return () => newMap.remove();
  }, []);

  // Add a marker function
  const addMarker = (lngLat, popupContent = '') => {
    if (!map) return;
    
    const marker = new mapboxgl.Marker()
      .setLngLat(lngLat)
      .setPopup(new mapboxgl.Popup().setHTML(popupContent))
      .addTo(map);
    
    setMarkers(prev => [...prev, marker]);
  };

  // Clear all markers
  const clearMarkers = () => {
    markers.forEach(marker => marker.remove());
    setMarkers([]);
  };

  return (
    <div className="map-container">
      <div ref={mapContainer} className="mapbox-map" />
    </div>
  );
};

export default MapboxMap;